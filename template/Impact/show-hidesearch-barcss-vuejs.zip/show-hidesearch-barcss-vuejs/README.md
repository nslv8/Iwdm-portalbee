# Show/Hide - Search Bar - CSS /  VueJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jreyesgs/pen/EWgBGM](https://codepen.io/jreyesgs/pen/EWgBGM).

